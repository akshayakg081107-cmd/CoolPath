# CoolPath Technical Design Document

## 1. Goal
Demonstrate a heat-aware route-comparison workflow for pedestrians, outdoor workers and local planning teams, aligned to the CoolPath concept deck.

## 2. Architecture
```text
Browser (HTML/CSS/JS)
        |
        | GET /api/routes?start=A&end=D
        v
Flask API (app.py)
        |
        v
Route engine (app/routing.py)
  - loads JSON street graph
  - shortest-distance Dijkstra
  - weighted heat/shade-cost Dijkstra
  - computes route summary metrics
        |
        v
Sample network (data/sample_network.json)
```

## 3. Data model
- Node: ID, label, latitude, longitude. Coordinates are illustrative and are not rendered as a real map.
- Edge: endpoints, distance in metres, heat risk [0,1], shade percentage [0,100], optional cooling-stop flag.
- Source timestamps and confidence are not yet modeled; these should be required in the real data pipeline.

## 4. Algorithm
The shortest route minimises summed distance. The heat-aware route minimises the sum of each edge's distance multiplied by a positive cost factor combining a baseline, heat risk and lack of shade. Route-level heat risk and shade are distance-weighted means. This makes the logic inspectable and straightforward to test.

## 5. API
`GET /api/routes?start=<node>&end=<node>`
- 200: `{ "routes": [...], "notice": "..." }`
- 400: `{ "error": "..." }`
Each route includes node sequence, human-readable places, distance, risk score, shade percentage, cooling-stop count, objective and explanation.

## 6. Privacy, safety and accessibility
The prototype stores no user accounts or personal data. It does not guarantee safety. Before a public pilot, obtain user feedback, review accessibility needs, show data sources and update times, communicate uncertainty, and direct users to official heat-health guidance.

## 7. Validation plan
- Unit-test route connectivity, metric ranges and invalid nodes.
- Compare results against manually inspected routes.
- Field-check cooling-point availability and shade at different times.
- Ask users and relevant civic/public-health stakeholders to review usability and risk communication.
- Calibrate weights only after collecting suitable observations.

## 8. Next steps
Integrate pedestrian GIS data, real route geometry, verified cooling points, weather inputs, time-of-day shade and a municipal data-quality dashboard. Any machine-learning component should be evaluated transparently and compared with this rule-based baseline.
