async function loadOptions() {
  // The node list is kept aligned with the documented sample dataset.
  const options = [["A","Campus Gate"],["B","Market Street"],["C","Tree-lined Lane"],["D","Bus Stop"]];
  for (const id of ["start","end"]) {
    document.getElementById(id).innerHTML = options.map(([v,label])=>`<option value="${v}">${label}</option>`).join("");
  }
  document.getElementById("end").value = "D";
}
function card(r, i) {
  return `<article class="route">
    <span class="badge">Option ${i+1}</span><h2>${r.objective}</h2>
    <div class="metric"><span>Distance</span><strong>${r.distance_m} m</strong></div>
    <div class="metric"><span>Relative heat-risk score</span><strong>${r.heat_risk_score}/100</strong></div>
    <div class="metric"><span>Estimated shade</span><strong>${r.shade_pct}%</strong></div>
    <div class="metric"><span>Mapped cooling stops</span><strong>${r.cooling_stops}</strong></div>
    <p class="path"><b>Route:</b> ${r.places.join(" → ")}</p><p>${r.explanation}</p>
  </article>`;
}
async function compare() {
  const status = document.getElementById("status");
  status.textContent = "Calculating routes…";
  try {
    const a = document.getElementById("start").value, b = document.getElementById("end").value;
    const response = await fetch(`/api/routes?start=${encodeURIComponent(a)}&end=${encodeURIComponent(b)}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not calculate routes");
    document.getElementById("routes").innerHTML = data.routes.map(card).join("") || '<div class="empty">No routes found.</div>';
    status.textContent = data.notice;
  } catch (e) { status.textContent = e.message; document.getElementById("routes").innerHTML = ""; }
}
document.getElementById("go").addEventListener("click", compare);
loadOptions().then(compare);
