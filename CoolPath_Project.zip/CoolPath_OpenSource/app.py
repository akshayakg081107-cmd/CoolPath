from flask import Flask, render_template, jsonify, request
from app.routing import load_network, recommend_routes
from pathlib import Path
import json

ROOT = Path(__file__).parent
app = Flask(__name__, template_folder="templates", static_folder="static")
NETWORK = load_network(ROOT / "data" / "sample_network.json")

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/routes")
def routes():
    try:
        start = request.args.get("start", "A")
        end = request.args.get("end", "D")
        routes = recommend_routes(NETWORK, start, end)
        return jsonify({"routes": routes, "notice": "Illustrative prototype scores only; not a safety guarantee."})
    except (ValueError, KeyError) as exc:
        return jsonify({"error": str(exc)}), 400

if __name__ == "__main__":
    app.run(debug=True)
